#include <WiFi.h>
#include <HTTPClient.h>
#include <ESP32Servo.h>
#include "DHT.h"
#include <LiquidCrystal_I2C.h>

// 1. Configuración de Red y API
const char* ssid = "Wokwi-GUEST";
const char* password = "";
const char* serverName = "	https://webhook.site/a1fef55b-e8c4-4a53-942d-1a3834dc0e9f"; // <--- CAMBIA ESTO

// Definición de Actuadores
Servo servoVent;
Servo servoRiego;
const int pinServoVent = 18;
const int pinServoRiego = 19;

// Config DHT y LCD
#define DHTPIN 15
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  Serial.begin(115200);
  dht.begin();
  
  // Inicializar Servos
  servoVent.attach(pinServoVent);
  servoRiego.attach(pinServoRiego);
  servoVent.write(0);
  servoRiego.write(0);

  // Inicializar LCD con Branding
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("BOLLOTECH V1.8");
  lcd.setCursor(0, 1);
  lcd.print("Conectando WiFi...");

  // Conexión WiFi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  
  lcd.clear();
  lcd.print("WiFi: ONLINE");
  delay(1500);
}

void loop() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();

  if (isnan(h) || isnan(t)) return;

  // Variables para el reporte
  String estadoVent = "OFF";
  String estadoRiego = "OFF";

  // --- LÓGICA DE CONTROL ---
  if (t > 30.0) {
    servoVent.write(90);
    estadoVent = "ON";
  } else {
    servoVent.write(0);
  }

  if (h < 40.0) {
    servoRiego.write(90);
    estadoRiego = "ON";
  } else {
    servoRiego.write(0);
  }

  // --- ACTUALIZAR PANTALLA ---
  lcd.setCursor(0, 0);
  lcd.print("T:"); lcd.print(t, 1); lcd.print(" V:"); lcd.print(estadoVent);
  lcd.setCursor(0, 1);
  lcd.print("H:"); lcd.print(h, 1); lcd.print(" R:"); lcd.print(estadoRiego);

  // --- ENVÍO DE DATOS POR WIFI ---
  if(WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(serverName);
    http.addHeader("Content-Type", "application/json");

    // Formateamos el JSON para Bollotech Cloud
    String httpRequestData = "{\"sensor_id\":\"FLORENTICA_01\",\"temp\":" + String(t) + 
                             ",\"hum\":" + String(h) + ",\"ventilador\":\"" + estadoVent + 
                             "\",\"riego\":\"" + estadoRiego + "\"}";
    
    int httpResponseCode = http.POST(httpRequestData);
    
    Serial.print("HTTP Response code: ");
    Serial.println(httpResponseCode);
    
    http.end();
  }

  delay(5000); // Enviamos reporte cada 5 segundos
}